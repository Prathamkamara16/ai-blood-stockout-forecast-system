from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from datetime import datetime, timezone
import sqlite3
from pathlib import Path
from datetime import date, timedelta
import pandas as pd
from sklearn.linear_model import LinearRegression

app = Flask(__name__)
app.secret_key = "prototype-secret-key"
DB = Path(__file__).with_name("database.db")
GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

def connect():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with connect() as c:
        c.execute("CREATE TABLE IF NOT EXISTS inventory(id INTEGER PRIMARY KEY, blood_group TEXT, units INTEGER, expiry_date TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS demand(id INTEGER PRIMARY KEY, blood_group TEXT, demand_date TEXT, units INTEGER)")
        c.execute("""CREATE TABLE IF NOT EXISTS sensor_readings(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT NOT NULL,
            temperature REAL NOT NULL,
            humidity REAL NOT NULL,
            recorded_at TEXT NOT NULL
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_sensor_recorded_at ON sensor_readings(recorded_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_sensor_device_time ON sensor_readings(device_id, recorded_at)")
        if c.execute("SELECT COUNT(*) FROM inventory").fetchone()[0] == 0:
            today = date.today()
            sample = [("A+",30,12),("B+",20,18),("O+",18,10),("AB+",12,25),("A-",8,7),("O-",10,14)]
            c.executemany("INSERT INTO inventory(blood_group,units,expiry_date) VALUES(?,?,?)",
                          [(g,u,(today+timedelta(days=d)).isoformat()) for g,u,d in sample])
        if c.execute("SELECT COUNT(*) FROM demand").fetchone()[0] == 0:
            today = date.today()
            patterns = {"A+":[3,4,2,4,3,5,4,3,4,5,3,4,4,5],
                        "B+":[2,3,4,2,3,4,3,2,4,3,4,3,5,4],
                        "O+":[4,5,4,6,5,4,7,5,6,5,7,6,5,7],
                        "AB+":[1,1,2,1,2,1,1,2,1,2,1,1,2,2],
                        "A-":[1,1,0,1,2,1,1,0,1,1,2,1,1,2],
                        "O-":[1,2,1,2,1,2,2,1,2,2,1,2,2,3]}
            records=[]
            for g, vals in patterns.items():
                for i, n in enumerate(vals):
                    records.append((g,(today-timedelta(days=len(vals)-i)).isoformat(),n))
            c.executemany("INSERT INTO demand(blood_group,demand_date,units) VALUES(?,?,?)", records)

def predict(group):
    with connect() as c:
        rows = c.execute("SELECT demand_date,units FROM demand WHERE blood_group=? ORDER BY demand_date",(group,)).fetchall()
    if not rows: return 0
    df = pd.DataFrame([dict(r) for r in rows])
    df["demand_date"] = pd.to_datetime(df["demand_date"])
    df["day"] = (df["demand_date"]-df["demand_date"].min()).dt.days
    if len(df) >= 5 and df["day"].nunique() > 1:
        model = LinearRegression().fit(df[["day"]], df["units"])
        last = int(df["day"].max())
        future = pd.DataFrame({"day": range(last+1,last+8)})
        return max(0, int(round(sum(max(0,float(x)) for x in model.predict(future)))))
    return max(0, int(round(df["units"].mean()*7)))

@app.route("/")
def dashboard():
    with connect() as c:
        stock = c.execute("SELECT blood_group,SUM(units) units,MIN(expiry_date) expiry FROM inventory GROUP BY blood_group ORDER BY blood_group").fetchall()
        total = c.execute("SELECT COALESCE(SUM(units),0) FROM inventory").fetchone()[0]
        near_expiry = c.execute("SELECT COUNT(*) FROM inventory WHERE expiry_date<=?",((date.today()+timedelta(days=7)).isoformat(),)).fetchone()[0]
    rows=[]
    for r in stock:
        forecast=predict(r["blood_group"]); units=int(r["units"] or 0); gap=max(0,forecast-units)
        risk="High" if gap else ("Watch" if units <= forecast*1.25 else "Low")
        rows.append(dict(group=r["blood_group"],units=units,forecast=forecast,gap=gap,risk=risk,expiry=r["expiry"]))
    return render_template("dashboard.html", rows=rows,total=total,near_expiry=near_expiry,high=sum(x["risk"]=="High" for x in rows),today=date.today().isoformat())

@app.route("/inventory",methods=["GET","POST"])
def inventory():
    if request.method=="POST":
        try:
            g=request.form["blood_group"]; units=int(request.form["units"]); expiry=request.form["expiry_date"]
            if g not in GROUPS or units<0: raise ValueError()
            date.fromisoformat(expiry)
        except (ValueError,KeyError):
            flash("Please enter valid inventory details.","error"); return redirect(url_for("inventory"))
        with connect() as c: c.execute("INSERT INTO inventory(blood_group,units,expiry_date) VALUES(?,?,?)",(g,units,expiry))
        flash("Inventory entry added.","success"); return redirect(url_for("inventory"))
    with connect() as c: items=c.execute("SELECT * FROM inventory ORDER BY expiry_date").fetchall()
    return render_template("inventory.html",items=items,groups=GROUPS,today=date.today().isoformat())

@app.route("/delete/<int:item_id>",methods=["POST"])
def delete(item_id):
    with connect() as c: c.execute("DELETE FROM inventory WHERE id=?",(item_id,))
    flash("Entry deleted.","success"); return redirect(url_for("inventory"))

@app.route("/demand",methods=["GET","POST"])
def demand():
    if request.method=="POST":
        try:
            g=request.form["blood_group"]; d=request.form["demand_date"]; units=int(request.form["units"])
            date.fromisoformat(d)
            if g not in GROUPS or units<0: raise ValueError()
        except (ValueError,KeyError):
            flash("Please enter valid demand details.","error"); return redirect(url_for("demand"))
        with connect() as c: c.execute("INSERT INTO demand(blood_group,demand_date,units) VALUES(?,?,?)",(g,d,units))
        flash("Demand record added.","success"); return redirect(url_for("demand"))
    with connect() as c: history=c.execute("SELECT * FROM demand ORDER BY demand_date DESC,id DESC LIMIT 40").fetchall()
    forecasts=[{"group":g,"units":predict(g)} for g in GROUPS]
    return render_template("demand.html",groups=GROUPS,history=history,forecasts=forecasts,today=date.today().isoformat())

@app.route("/forecast")
def forecast():
    rows=[]
    for g in GROUPS:
        with connect() as c:
            usable=c.execute("SELECT COALESCE(SUM(units),0) FROM inventory WHERE blood_group=? AND expiry_date>?",(g,date.today().isoformat())).fetchone()[0]
        f=predict(g); rows.append({"group":g,"stock":int(usable),"forecast":f,"gap":max(0,f-int(usable))})
    return render_template("forecast.html",rows=rows)

init_db()
if __name__=="__main__":
    app.run(debug=True)
