# Copy this file to secrets.h and enter your own network details.
#define WIFI_SSID "YOUR_WIFI_NAME"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
// Use your Windows laptop's LAN IPv4 address, e.g. http://192.168.1.10:5000
#define FLASK_BASE_URL "http://192.168.1.10:5000"
