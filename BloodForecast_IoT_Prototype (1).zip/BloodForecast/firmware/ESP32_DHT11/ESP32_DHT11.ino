/*
  BloodForecast ESP32 + DHT11
  Wiring (DHT11 module): VCC->3V3, GND->GND, DATA->GPIO4
  For a bare 4-pin DHT11, add a 4.7k-10k pull-up from DATA to 3V3.
  Configure credentials in secrets.h (do not publish that file).
*/
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include "secrets.h"

#define DHTPIN 4
#define DHTTYPE DHT11
#define DEVICE_ID "ESP32_BLOOD_001"
#define SEND_INTERVAL_MS 5000

DHT dht(DHTPIN, DHTTYPE);
unsigned long lastSend = 0;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.print("Connecting to Wi-Fi");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < 20000) {
    delay(500); Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWi-Fi connected");
    Serial.print("ESP32 IP: "); Serial.println(WiFi.localIP());
  } else Serial.println("\nWi-Fi connection timed out; will retry.");
}

void sendReading(float temperature, float humidity) {
  if (WiFi.status() != WL_CONNECTED) { Serial.println("Wi-Fi offline; reading not sent."); return; }
  HTTPClient http;
  String url = String(FLASK_BASE_URL) + "/api/sensor-data";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  String payload = "{\"device_id\":\"" DEVICE_ID "\",\"temperature\":" +
                   String(temperature, 1) + ",\"humidity\":" + String(humidity, 1) + "}";
  int code = http.POST(payload);
  Serial.print("POST "); Serial.print(url); Serial.print(" -> HTTP "); Serial.println(code);
  if (code > 0) Serial.println(http.getString());
  else Serial.println(http.errorToString(code));
  http.end();
}

void setup() {
  Serial.begin(115200);
  delay(500);
  dht.begin();
  connectWiFi();
}

void loop() {
  connectWiFi();
  if (millis() - lastSend >= SEND_INTERVAL_MS) {
    lastSend = millis();
    float humidity = dht.readHumidity();
    float temperature = dht.readTemperature();
    if (isnan(temperature) || isnan(humidity)) {
      Serial.println("DHT11 read failed. Check VCC, GND, DATA and pull-up.");
    } else if (humidity < 0 || humidity > 100 || temperature < -10 || temperature > 60) {
      Serial.println("Sensor value outside expected DHT11 range; skipped.");
    } else {
      Serial.printf("Temperature: %.1f C | Humidity: %.1f %%\n", temperature, humidity);
      sendReading(temperature, humidity);
    }
  }
  delay(50);
}
