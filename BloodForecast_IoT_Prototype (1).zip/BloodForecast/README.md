# BloodForecast — ESP32 + DHT11 IoT Prototype

## What is included
- Existing inventory, demand history and 7-day forecast pages retained.
- New `/iot` monitoring page.
- `POST /api/sensor-data`, `GET /api/latest-reading`, `GET /api/readings`, and `GET /api/device-status`.
- SQLite `sensor_readings` table created without deleting existing inventory or demand data.
- ESP32 Arduino firmware in `firmware/ESP32_DHT11/`.

## Windows setup
Open PowerShell in this `BloodForecast` folder:

```powershell
python -m venv venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`. For ESP32 access, keep Flask running; it listens on `0.0.0.0:5000`.

## Hardware wiring
For a 3-pin DHT11 module:
| DHT11 | ESP32 |
|---|---|
| VCC | 3V3 |
| GND | GND |
| DATA/S | GPIO 4 |

For a bare 4-pin DHT11 (front grille facing you; confirm the exact datasheet/pinout for your part), connect VCC to 3V3, DATA to GPIO4, GND to GND, leave NC unconnected, and add a 4.7k–10k pull-up resistor between DATA and 3V3. Never feed 5V into ESP32 GPIO.

## Arduino IDE
1. Install Arduino IDE and add the Espressif ESP32 board package.
2. Install the `DHT sensor library` by Adafruit (and `Adafruit Unified Sensor` if Library Manager requests it).
3. Open `firmware/ESP32_DHT11/ESP32_DHT11.ino`.
4. Copy `secrets.example.h` to `secrets.h` in the same folder.
5. Edit Wi-Fi SSID/password and `FLASK_BASE_URL`. Find the laptop IPv4 address using `ipconfig`; use `http://LAPTOP_IPV4:5000`, not `127.0.0.1`.
6. Select the correct ESP32 board and COM port, upload, then open Serial Monitor at 115200 baud.

## Network and firewall
Laptop and ESP32 must be on the same Wi-Fi/LAN. Allow Python through Windows Defender Firewall on private networks if prompted. Guest Wi-Fi or client isolation may prevent device-to-device traffic. Do not expose this unauthenticated demo API to the public internet.

## Verify API without hardware
With Flask running, in another PowerShell window:

```powershell
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:5000/api/sensor-data -ContentType 'application/json' -Body '{"device_id":"TEST_ONLY","temperature":24.5,"humidity":50}'
Invoke-RestMethod http://127.0.0.1:5000/api/latest-reading
```

This is a clearly labelled manual test, not a physical sensor reading. Delete `database.db` only if you intentionally want to reset all prototype data.

## Monitoring behavior
- Dashboard polls backend every 5 seconds.
- Device is ONLINE if its latest accepted reading is no older than 30 seconds.
- Demo temperature thresholds default to 2°C and 6°C and can be changed in the page.
- Historical readings are real records received by Flask; no random values are generated.

## Important safety limitation
DHT11 is a low-cost educational room-environment sensor with limited accuracy and range. It is not suitable for validated blood component storage or clinical decisions. Thresholds are demonstration settings only. Real deployment requires calibrated, appropriately rated sensors, validated placement, continuous monitoring, alarm escalation, audit controls and regulatory review.
